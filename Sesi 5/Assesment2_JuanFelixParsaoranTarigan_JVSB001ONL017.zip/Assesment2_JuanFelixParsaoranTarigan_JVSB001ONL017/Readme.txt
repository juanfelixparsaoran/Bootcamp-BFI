Panduan Tugas 2
Nama         : Juan Felix Parsaoran Tarigan
Kode Peserta : JVSB001ONL017
Link Github  : https://github.com/juanfelixparsaoran/Bootcamp-BFI/tree/main/Sesi%205/Assesment_JuanFelixParsaoranTarigan_JVSB001ONL017
Panduan Penggunaan Aplikasi:

1. Bilangan
Program ini digunakan untuk menentukan nilai maksimum, minimum, dan rata-rata dari 3 nilai inputan user.

2. Tempat Duduk
Program ini digunakan untuk menampilkan tempat duduk dari list bahasa pemrograman berdasarkan indeks mereka 
pada array multidimensi.

3. Diskon
Program ini digunakan untuk menentukan harga bayar dari inputan harga pembelian. Jika harga pembelian >= 1000000,
maka harga beli mendapatkan diskon 10%.

4. Tahun Kabisat
Program ini digunakan untuk menentukan apakah tahun inputan merupakan tahun kabisat atau tidak.
Syarat tahun kabisat adalah tahun tersebut habis dibagi 400 saat tahun tersebut dapat dibagi 100, dan
habis dibagi 4 saat tahun tersebut tidak habis dibagi 100.

5. Penjualan
Program ini digunakan untuk menampilkan detail pembelian oleh inputan pengguna. Model barang dibuat dalam
barang.java.

Pertama-tama, pengguna menginput berapa barang yang akan dibeli, lalu pengguna menginput kode barang dan
jumlah barang yang akan dibeli. Setelah itu, program akan menampilkan detail barang dan total harga yang
harus dibayar oleh pengguna.