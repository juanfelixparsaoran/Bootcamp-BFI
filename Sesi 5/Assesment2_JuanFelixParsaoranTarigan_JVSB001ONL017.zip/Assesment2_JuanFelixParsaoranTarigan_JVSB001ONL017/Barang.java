public class Barang {
    String nama;
    int kode,harga,diskon;

    //Constructor
    Barang (int kode,String nama, int harga, int diskon){
        this.kode = kode;
        this.nama = nama;
        this.harga = harga;
        this.diskon = diskon;
    }
    
}
