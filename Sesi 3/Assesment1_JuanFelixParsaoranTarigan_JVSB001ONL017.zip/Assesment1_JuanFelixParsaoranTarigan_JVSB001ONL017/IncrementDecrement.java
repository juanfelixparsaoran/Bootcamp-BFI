public class IncrementDecrement {
    public static void main(String[] args) {
        int a = 0, b = 0, c=9, d=9;

        //Print ke 1
        System.out.println("Print ke 1");
        System.out.println("A = " + a++); //hasil  A = 0
        System.out.println("B = " + ++b); //hasil  B = 1
        System.out.println("C = " + c--); //hasil  C = 9
        System.out.println("D = " + --d); //hasil  D = 8

        //Print ke 2
        System.out.println("Print ke 2");
        System.out.println("A = " + a++);
        System.out.println("B = " + ++b);
        System.out.println("C = " + c--);
        System.out.println("D = " + --d);

        //Print ke 3
        System.out.println("Print ke 3");
        System.out.println("A = " + a++);
        System.out.println("B = " + ++b);
        System.out.println("C = " + c--);
        System.out.println("D = " + --d);

        //Print ke 4
        System.out.println("Print ke 4");
        System.out.println("A = " + a++);
        System.out.println("B = " + ++b);
        System.out.println("C = " + c--);
        System.out.println("D = " + --d);

    }
}
