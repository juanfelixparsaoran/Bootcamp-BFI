Nama : Juan Felix Parsaoran Tarigan
Kode Peserta : JVSB001ONL017
Link Github : https://github.com/juanfelixparsaoran/Bootcamp-BFI/tree/main/Sesi%2017/BelajarSpringProduct

Panduan Penggunaan Aplikasi:
Program ini merupakan program REST API sederhana dengan menggunaan Spring Boot. Terdapat service CRUD untuk 
tabel product pada database dan landing page untuk mengetahui dokumentasi postman program.

Cara menjalankan program:
1. update project, mvn clean, mvn install
2. run as spring boot project