package com.belajar.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarSpringProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelajarSpringProductApplication.class, args);
	}

}
